package com.example.wliautosearch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.asPaddingValues

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainScreen()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    // IP-adress är låst och syns ej
    val ip = "192.168.4.1"

    var sweepTime by remember { mutableStateOf("") }
    var timeout by remember { mutableStateOf("") }
    var speed by remember { mutableStateOf(125) } // 75..250, steg 25
    var status by remember { mutableStateOf("Status: -") }
    var connectionStatus by remember { mutableStateOf("Ingen anslutning") }
    var isTesting by remember { mutableStateOf(false) }

    // Funktion för att testa anslutning
    fun testConnection() {
        isTesting = true
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = URL("http://$ip/")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 1500
                conn.readTimeout = 1500
                conn.requestMethod = "GET"
                val code = conn.responseCode
                conn.disconnect()
                withContext(Dispatchers.Main) {
                    isTesting = false
                    connectionStatus = if (code == 200) "Ansluten" else "Ingen anslutning"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    isTesting = false
                    connectionStatus = "Ingen anslutning"
                }
            }
        }
    }

    // Testa anslutning automatiskt vid appstart
    LaunchedEffect(Unit) {
        testConnection()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(WindowInsets.statusBars.asPaddingValues())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Status för anslutning: $connectionStatus")
        Button(
            onClick = { testConnection() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isTesting
        ) {
            if (isTesting) Text("Testar...") else Text("Testa anslutning")
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = { sendCommand(ip, "RIGHT") { status = it } },
                modifier = Modifier.weight(1f)
            ) { Text("Höger") }
            Button(
                onClick = { sendCommand(ip, "LEFT") { status = it } },
                modifier = Modifier.weight(1f)
            ) { Text("Vänster") }
            Button(
                onClick = { sendCommand(ip, "STOP") { status = it } },
                modifier = Modifier.weight(1f)
            ) { Text("Stopp") }
            Button(
                onClick = { sendCommand(ip, "SWEEP") { status = it } },
                modifier = Modifier.weight(1f)
            ) { Text("Svep") }
        }

        // Motor speed med steg om 25, min 75, max 250
        Text("Hastighet: $speed")
        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    if (speed > 75) {
                        speed -= 25
                        sendCommand(ip, "SPEED=$speed") { status = it }
                    }
                },
                enabled = speed > 75
            ) { Text("-") }
            Slider(
                value = speed.toFloat(),
                onValueChange = {
                    // Hoppa till närmaste steg om 25
                    val newVal = ((it / 25).toInt() * 25).coerceIn(75, 250)
                    if (newVal != speed) {
                        speed = newVal
                        sendCommand(ip, "SPEED=$speed") { status = it }
                    }
                },
                valueRange = 75f..250f,
                steps = ((250 - 75) / 25) - 1,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    if (speed < 250) {
                        speed += 25
                        sendCommand(ip, "SPEED=$speed") { status = it }
                    }
                },
                enabled = speed < 250
            ) { Text("+") }
        }

        OutlinedTextField(
            value = sweepTime,
            onValueChange = { sweepTime = it },
            label = { Text("Sveptid (sekunder)") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Button(
            onClick = {
                sendCommand(ip, "SWEEPTIME=$sweepTime") { result ->
                    status = "Bekräftelse: $result"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Sätt sveptid") }

        OutlinedTextField(
            value = timeout,
            onValueChange = { timeout = it },
            label = { Text("Larmtid (sekunder)") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Button(
            onClick = {
                sendCommand(ip, "TIMEOUT=$timeout") { result ->
                    status = "Bekräftelse: $result"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Sätt larmtid") }

        Button(
            onClick = {
                sendCommand(ip, "") { result ->
                    status = result
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Hämta status") }

        Text(status, modifier = Modifier.padding(top = 16.dp))
    }
}

fun sendCommand(ip: String, cmd: String, onResult: (String) -> Unit) {
    if (ip.isBlank()) {
        onResult("IP-adress saknas!")
        return
    }
    CoroutineScope(Dispatchers.IO).launch {
        try {
            val url = URL("http://$ip/$cmd")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 2000
            connection.readTimeout = 2000
            val response = connection.inputStream.bufferedReader().readText()
            connection.disconnect()

            // Extrahera hastighet och svepläge ur HTML, om det finns
            val speedRegex = Regex("Speed: (\\d+)")
            val sweepRegex = Regex("Sweep mode: ([A-Z]+)")
            val sweepTimeRegex = Regex("Sweep time: (\\d+)")
            val speed = speedRegex.find(response)?.groupValues?.get(1) ?: "?"
            val sweep = sweepRegex.find(response)?.groupValues?.get(1) ?: "?"
            val sweepTime = sweepTimeRegex.find(response)?.groupValues?.get(1) ?: "?"

            val display = if (response.contains("Speed:") && response.contains("Sweep mode:")) {
                "Hastighet: $speed\nSvepläge: $sweep\nSveptid: $sweepTime s"
            } else {
                response
            }


            withContext(Dispatchers.Main) { onResult(display) }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) { onResult("Fel: ${e.localizedMessage}") }
        }
    }
}
